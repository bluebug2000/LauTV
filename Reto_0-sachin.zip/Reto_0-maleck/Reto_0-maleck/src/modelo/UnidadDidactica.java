/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author 2dam
 */
public class UnidadDidactica {
    private Integer id;
    private String acronimo;
    private String titulo;
    private String evaluacion;
    private String descripcion;

    public UnidadDidactica() {
    }

    public Integer getId() {
        return id;
    }

    public String getAcronimo() {
        return acronimo;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getEvaluacion() {
        return evaluacion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setAcronimo(String acronimo) {
        this.acronimo = acronimo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setEvaluacion(String evaluacion) {
        this.evaluacion = evaluacion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
    return "----------------------------------------\n" +
           "ID: " + id + "\n" +
           "Acrónimo: " + acronimo + "\n" +
           "Título: " + titulo + "\n" +
           "Evaluación: " + evaluacion + "\n" +
           "Descripción: " + descripcion + "\n" +
           "----------------------------------------";
}

    
    
    
}
